/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.web;

import nl.kb.kbga.geoservice.service.GeoPaperService;
import nl.kb.kbga.geoservice.transform.GeoServiceResultSet;
import nl.kb.kbga.geoservice.web.helpers.formatter.Param;
import nl.kb.kbga.geoservice.web.helpers.formatter.ResponseFormat;
import nl.kb.kbga.geoservice.web.helpers.validation.DoubleParser;
import nl.kb.kbga.geoservice.web.helpers.validation.IntegerParser;

import javax.ejb.EJB;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Handles all requests concerning geo location search.
 * Receives request parameters lat, lon, limit and offset.
 * Returns a list of closest articles and image urls for
 * the first article.
 */
public class GeosearchServlet extends HttpServlet {

    @SuppressWarnings({"UnusedDeclaration"})
    private static final long serialVersionUID = 1L;

    private static final String RESPONSE_FORMAT_INIT_PARAM_NAME = "responseFormat";
    private static final String LAT_PARAM_NAME = "lat";
    private static final String LON_PARAM_NAME = "lon";
    private static final String WIDTH_PARAM_NAME = "width";
    private static final String OFFSET_PARAM_NAME = "offset";
    private static final String LIMIT_PARAM_NAME = "limit";
    private static final String QUALITY_PARAM_NAME = "quality";

    @EJB
    private GeoPaperService service;

    /**
	 * {@inheritDoc}
	 * @See javax.servlet.http.HttpServlet#service()
	 */
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

        final ResponseFormat responseFormat = ResponseFormat.valueOf(getInitParameter(RESPONSE_FORMAT_INIT_PARAM_NAME));

        response.setContentType(responseFormat.getContentType());
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        try {
            DoubleParser doubleParser = DoubleParser.getInstance();
            IntegerParser integerParser = IntegerParser.getInstance();
            double latParam = doubleParser.parseParam(request.getParameter(Param.LAT.getName()), Param.LAT);
            double lonParam = doubleParser.parseParam(request.getParameter(Param.LON.getName()), Param.LON);
            int limitParam = integerParser.parseParam(request.getParameter(Param.LIMIT.getName()), Param.LIMIT);
            int offsetParam = integerParser.parseParam(request.getParameter(Param.OFFSET.getName()), Param.OFFSET);
            int widthParam = integerParser.parseParam(request.getParameter(Param.WIDTH.getName()), Param.WIDTH);
            int qualityParam = integerParser.parseParam(request.getParameter(Param.QUALITY.getName()), Param.QUALITY);

            GeoServiceResultSet resultSet =
                    service.proximitySearch(latParam, lonParam, offsetParam, limitParam, widthParam, qualityParam);

            responseFormat.marshall(resultSet, out);
        } catch(Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            try {
                responseFormat.marshall(e, out);
            } catch(Exception ex) {
                throw new ServletException(ex);
            }
        }
	}

	/**
	 * {@inheritDoc}
	 * @See javax.servlet.http.HttpServlet#init()
	 */
	@Override
	public synchronized void init() throws ServletException {

		try {
			if (service == null) {
				service = (GeoPaperService)
					new InitialContext().lookup("geoservice-ear/GeoPaperServiceImpl/local");
			}
		} catch (NamingException ne) {
			throw new RuntimeException("cannot get a hanlde to GeoPaperService ejb.", ne);
		}
		super.init();
	}

}
