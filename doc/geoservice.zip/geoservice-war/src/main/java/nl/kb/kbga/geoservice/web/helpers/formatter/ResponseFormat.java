/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.web.helpers.formatter;

import nl.kb.kbga.geoservice.transform.GeoServiceResultSet;
import org.codehaus.jettison.AbstractXMLStreamWriter;
import org.codehaus.jettison.mapped.MappedNamespaceConvention;
import org.codehaus.jettison.mapped.MappedXMLStreamWriter;

import javax.servlet.ServletException;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.stream.XMLStreamWriter;
import java.io.Writer;

/**
 * Packages properties and methods specific to response formats XML and JSON.
 */
public enum ResponseFormat {
    XML("text/xml"),
    JSON("application/json");

    private static final JAXBContext JAXB_CONTEXT;
    static {
        try {
            JAXB_CONTEXT = JAXBContext.newInstance(GeoServiceResultSet.class, ExceptionWrapper.class);
        } catch(JAXBException e) {
            throw new RuntimeException(e);
        }
    }

    private String contentType;

    /**
     * Constructor.
     * @param contentType the HTTP content type value
     */
    ResponseFormat(String contentType) {
        this.contentType = contentType;
    }

    /**
     * @param format String representation of response format
     * @return enum representation of response format
     */
    public static ResponseFormat load(String format) {
        if(ResponseFormat.XML.toString().equalsIgnoreCase(format)) {
            return ResponseFormat.XML;
        }
        return ResponseFormat.JSON;
    }

    /**
     * @param exception the checked exception
     * @param out the writer to marshall to
     * @throws ServletException when marshalling fails
     */
    public void marshall(Exception exception, Writer out) throws ServletException {
        try {
            marshall(new ExceptionWrapper(exception), out);
        } catch(JAXBException e) {
            throw new ServletException("Cannot marshall exception: " + e.getMessage(), e);
        }
    }

    /**
     * Marshall an object to chosen format.
     * @param object the object to be marshalled
     * @param out the writer to marshall to
     * @throws JAXBException when marshalling fails
     */
    public void marshall(Object object, Writer out) throws JAXBException {
        Marshaller marshaller = JAXB_CONTEXT.createMarshaller();
        if(this == ResponseFormat.JSON) {
            MappedNamespaceConvention convention = new MappedNamespaceConvention();
            AbstractXMLStreamWriter abstractXMLStreamWriter = new MappedXMLStreamWriter(convention, out);
            marshaller.marshal(object, (XMLStreamWriter) abstractXMLStreamWriter);
        } else {
            marshaller.marshal(object, out);
        }
    }

    /**
     * @return the HTTP content type value
     */
    public String getContentType() {
        return contentType;
    }

}
