/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.web.helpers.validation;

import nl.kb.kbga.geoservice.web.helpers.formatter.Param;

/**
 * Responsible for validating a URL parameter and converting it to type T.
 * @param <T> typecast for the validator extending this class
 */
public abstract class ParamParser<T> {
    private ValidationConfig validationConfig = ValidationConfig.getInstance("/customconf/geoservice/validation.xml");

    /**
     * Constructor.
     */
    public ParamParser() { }


    /**
     * @return The validation configuration
     */
    public ValidationConfig getValidationConfig() {
        return validationConfig;
    }

    /**
     * Parses parameter to the expected type.
     * @param paramValue string value of the parameter
     * @param param enum value representing parameter name and default value
     * @return the type-casted parameter
     * @throws ParamValidationException when param does not validate
     */
    public T parseParam(String paramValue, Param param) throws ParamValidationException {
        return parseParam(paramValue, param.getName(), param.getDefaultValue());
    }

    /**
     * Parses the parameter to the expected type.
     * Also expects a name for the parameter.
     * @param param the parameter
     * @param paramName name for the parameter
     * @return the type-casted parameter
     * @throws ParamValidationException when param does not validate
     */
    public T parseParam(String param, String paramName) throws ParamValidationException {
        return parseParam(param, paramName, null);
    }

    /**
     * Parses the parameter to the expected type.
     * Expects a name for the parameter as well as a default value.
     * If default value is set to null, the parameter may not be null, else
     * the return value will be the type-casted default value
     * @param param the parameter
     * @param paramName name for the parameter
     * @param defaultValue the type-casted parameter
     * @return the type-casted parameter
     * @throws ParamValidationException when param does not validate
     */
    public abstract T parseParam(String param, String paramName, String defaultValue) throws ParamValidationException;

    /**
     * Validates parameter value against given validation restrictions.
     * @param paramName name of the parameter (to be looked up in validationConfig)
     * @param value type-casted value of the parameter
     * @throws ParamValidationException when param does not validate
     */
    protected abstract void validate(String paramName, T value) throws ParamValidationException;
}
