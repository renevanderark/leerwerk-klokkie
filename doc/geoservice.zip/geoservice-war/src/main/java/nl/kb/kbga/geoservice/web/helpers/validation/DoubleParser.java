/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.web.helpers.validation;

/**
 * {@inheritDoc}
 * @See nl.kb.kbga.geopaper.web.helpers.ParamParser
 */
public final class DoubleParser extends ParamParser<Double> {

    private static final DoubleParser INSTANCE = new DoubleParser();

    /**
     * Private constructor.
     */
    private DoubleParser() {
    }

    /**
     * @return singleton instance of parser
     */
    public static DoubleParser getInstance() {
        return INSTANCE;
    }

    /**
     * {@inheritDoc}
     * @See nl.kb.kbga.geopaper.web.helpers.ParamParser#parseParam
     */
    public Double parseParam(String param, String paramName, String defaultValue) throws ParamValidationException {
        if(param == null) {
            if(defaultValue == null)
                throw new NullPointerException("Required parameter " + paramName + " not supplied");
            else
                param = defaultValue;
        }
        try {
            Double value = Double.parseDouble(param);
            validate(paramName, value);
            return value;
        } catch(NumberFormatException e) {
            throw new NumberFormatException("Parameter " + paramName + " has invalid format");
        }
    }

    /**
     * {@inheritDoc}
     * @See nl.kb.kbga.geopaper.web.helpers.ParamParser#validate
     */
    protected void validate(String paramName, Double value) throws ParamValidationException {
        ValidationConfig  config = getValidationConfig();
        final String paramKey = "param.";
        final String maxValidEntry = config.getProperty(paramKey + paramName + ".restriction.max");
        final String minValidEntry = config.getProperty(paramKey + paramName + ".restriction.min");
        if(maxValidEntry != null) {
            double maxValid = Double.parseDouble(maxValidEntry);
            if(value > maxValid) {
                String protoMessage = config.getProperty("message.max");
                throw new ParamValidationException(protoMessage, paramName, ""+maxValid, ""+value);
            }
        }
        if(minValidEntry != null) {
            double minValid = Double.parseDouble(minValidEntry);
            if(value < minValid) {
                String protoMessage = config.getProperty("message.min");
                throw new ParamValidationException(protoMessage, paramName, ""+minValid, ""+value);
            }
        }
    }
}
