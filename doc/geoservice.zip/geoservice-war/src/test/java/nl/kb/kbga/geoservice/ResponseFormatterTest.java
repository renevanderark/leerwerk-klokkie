package nl.kb.kbga.geoservice;

import junit.framework.TestCase;
import nl.kb.kbga.geoservice.model.Article;
import nl.kb.kbga.geoservice.model.ArticleZone;
import nl.kb.kbga.geoservice.transform.GeoServiceResultSet;
import nl.kb.kbga.geoservice.transform.ImageViewerConfig;
import nl.kb.kbga.geoservice.web.helpers.formatter.ResponseFormat;
import org.apache.log4j.BasicConfigurator;
import org.codehaus.jettison.AbstractXMLStreamWriter;
import org.codehaus.jettison.mapped.MappedNamespaceConvention;
import org.codehaus.jettison.mapped.MappedXMLStreamWriter;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ResponseFormatterTest extends TestCase {
    private static final JAXBContext JAXB_CONTEXT_RESULTSET;
    private static ImageViewerConfig imageViewerConfig;

    static {
        try {
            JAXB_CONTEXT_RESULTSET = JAXBContext.newInstance(GeoServiceResultSet.class);
        } catch(JAXBException e) {
            throw new RuntimeException(e);
        }
    }
    static {
        BasicConfigurator.configure();
    }

    private ArrayList<Article> articleList;
    private ArrayList<ArticleZone> articleZoneList;

    public void setUp() throws Exception {
        Article article = new Article();
        System.setProperty("jboss.server.base.dir", "");
        imageViewerConfig = ImageViewerConfig.getInstance(this.getClass().getResource("/imageviewer.xml").getPath());

        article.setTitle("foo");
        article.setArticleUrn("foo:bar");
        article.setPaperTitle("test");
        article.setLatitude(1D);
        article.setLongitude(1D);
        article.setDate(new Date());
        articleList = new ArrayList<Article>();
        articleList.add(article);

        ArticleZone articleZone = new ArticleZone();
        articleZone.setWidth(10);
        articleZone.setHeight(10);
        articleZone.setHpos(5);
        articleZone.setVpos(5);
        articleZone.setArticleUrn("asd");
        articleZone.setImageUrn("asd");
        articleZone.setArticleUrn("asd");
        articleZone.setResponseWidth(10);
        articleZoneList = new ArrayList<ArticleZone>();
        articleZoneList.add(articleZone);
    }

    @SuppressWarnings("unchecked")
    public void testJSONResponse() throws Exception {
        GeoServiceResultSet resultSet = new GeoServiceResultSet();
        resultSet.setArticles(articleList);
        resultSet.setImages(articleZoneList, new String[]{}, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));

        StringWriter stringWriter = new StringWriter();
        Marshaller marshaller = JAXB_CONTEXT_RESULTSET.createMarshaller();
        MappedNamespaceConvention convention = new MappedNamespaceConvention();
        AbstractXMLStreamWriter writer = new MappedXMLStreamWriter(convention, stringWriter);
        marshaller.marshal(resultSet, (XMLStreamWriter) writer);
        System.out.println(stringWriter.toString());
        Map<String, Object> responderJSON = (Map<String, Object>) new JSONParser().parse(stringWriter.toString(), new ContainerFactory() {
            public Map createObjectContainer() { return new HashMap(); }
            public List creatArrayContainer() { return new ArrayList(); }
        });
        Map<String, Object> results = (Map<String, Object>) responderJSON.get("results");
        Map<String, Object> articles = (Map<String, Object>) results.get("articles");
        Map<String, String> record = (Map<String, String>) articles.get("record");
        assertEquals(record.get("title"), "foo");
        assertEquals(record.get("papertitle"), "test");
        assertEquals(record.get("urn"), "foo:bar");

        Map<String, Map<String, String>> image = (Map<String, Map<String, String>>) results.get("images");
        //noinspection AssertEqualsBetweenInconvertibleTypes
        assertEquals(imageViewerConfig.getProperty("baseUrl") + "?id=asd%3Aimage&x=5&y=5&w=10&h=10&s=1.0&q=" + imageViewerConfig.getProperty("paramValue.q"), image.get("record"));
    }

    public void testXMLResponse() throws Exception {
        GeoServiceResultSet resultSet = new GeoServiceResultSet();
        resultSet.setArticles(articleList);
        resultSet.setImages(articleZoneList, new String[]{}, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));
        Marshaller marshaller = JAXB_CONTEXT_RESULTSET.createMarshaller();
        StringWriter out = new StringWriter();
        marshaller.marshal(resultSet, out);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(false);
        Document doc = factory.newDocumentBuilder().parse(new InputSource(new StringReader(out.toString())));

        evaluateXPath(doc, "/results/articles/record/urn", "urn", "foo:bar");
        evaluateXPath(doc, "/results/articles/record/title", "title", "foo");
        evaluateXPath(doc, "/results/articles/record/papertitle", "papertitle", "test");
        evaluateXPath(doc, "/results/images/record", "record", imageViewerConfig.getProperty("baseUrl") + "?id=asd%3Aimage&x=5&y=5&w=10&h=10&s=1.0&q=" + imageViewerConfig.getProperty("paramValue.q"));
    }

    public void testExceptionFormatterXML() throws Exception {
        ResponseFormat responseFormatXML = ResponseFormat.XML;
        StringWriter writer = new StringWriter();
        responseFormatXML.marshall(new NumberFormatException("test message"), writer);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(false);
        Document doc = factory.newDocumentBuilder().parse(new InputSource(new StringReader(writer.toString())));
        evaluateXPath(doc, "/exception/message", "message", "test message");
        evaluateXPath(doc, "/exception/type", "type", "NumberFormatException");
    }

    public void testExceptionFormatterJSON() throws Exception {
        ResponseFormat responseFormatJSON = ResponseFormat.JSON;
        StringWriter writer = new StringWriter();
        responseFormatJSON.marshall(new NumberFormatException("test message"), writer);
        @SuppressWarnings("unchecked")
        Map<String, Map<String, String>> exceptionJSON = (Map<String, Map<String, String>>) new JSONParser().parse(writer.toString(),
            new ContainerFactory() {
                public Map createObjectContainer() { return new HashMap(); }
                public List creatArrayContainer() { return new ArrayList(); }
            }
        );
        assertEquals("test message", exceptionJSON.get("exception").get("message"));
        assertEquals("NumberFormatException", exceptionJSON.get("exception").get("type"));
    }

    private void evaluateXPath(Document doc, String expression, String nodeName, String value) throws Exception {
        XPath xpath = XPathFactory.newInstance().newXPath();
        XPathExpression expr = xpath.compile(expression);
        Node node = ((NodeList) expr.evaluate(doc, XPathConstants.NODESET)).item(0);
        assertEquals(nodeName, node.getNodeName());
        assertEquals(value, node.getTextContent());
    }
}
