package nl.kb.kbga.geoservice;

import junit.framework.TestCase;
import nl.kb.kbga.geoservice.web.helpers.validation.ParamValidationException;
import nl.kb.kbga.geoservice.web.helpers.validation.StringValidator;
import nl.kb.kbga.geoservice.web.helpers.validation.ValidationConfig;
import org.apache.log4j.BasicConfigurator;

public class StringValidatorTest extends TestCase {
        static { BasicConfigurator.configure(); }

    private static ValidationConfig validationConfig;
    private static StringValidator stringValidator;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty("jboss.server.base.dir", "");
        validationConfig = ValidationConfig.getInstance(this.getClass().getResource("/validation.xml").getPath());
        stringValidator = StringValidator.getInstance();
    }


    public void testAgainstInjection() throws Exception {
        try {
            stringValidator.parseParam("SELECT * FROM artikelen", "articleUrn");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.pattern", "articleUrn",
                    validationConfig.getProperty("param.articleUrn.restriction.pattern"), "SELECT * FROM artikelen"));
        }
    }

    public void testForCorrectPattern() throws Exception {
        try {
            stringValidator.parseParam("asd:123456789:mpeg21:1234", "articleUrn");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.pattern", "articleUrn",
                    validationConfig.getProperty("param.articleUrn.restriction.pattern"), "asd:123456789:mpeg21:1234"));
        }

        String result = stringValidator.parseParam("ddd:123546789:mpeg21:a1234", "articleUrn");
        assertEquals("ddd:123546789:mpeg21:a1234", result);

    }

    private static String expectMessage(String propertyName, String paramName, String restrictionValue, String paramValue) {
        return validationConfig.getProperty(propertyName)
                .replace("##PARAM_NAME##", paramName)
                .replace("##RESTRICTION_VALUE##", restrictionValue)
                .replace("##PARAM_VALUE##", paramValue);

    }

}
