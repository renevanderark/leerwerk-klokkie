package nl.kb.kbga.geoservice;

import junit.framework.TestCase;
import nl.kb.kbga.geoservice.web.helpers.validation.DoubleParser;
import nl.kb.kbga.geoservice.web.helpers.validation.IntegerParser;
import nl.kb.kbga.geoservice.web.helpers.validation.ParamValidationException;
import nl.kb.kbga.geoservice.web.helpers.validation.ValidationConfig;
import org.apache.log4j.BasicConfigurator;

public class ParamParserTest extends TestCase {
    static { BasicConfigurator.configure(); }

    private static ValidationConfig validationConfig;
    private static DoubleParser doubleParser;
    private static IntegerParser integerParser;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty("jboss.server.base.dir", "");
        validationConfig = ValidationConfig.getInstance(this.getClass().getResource("/validation.xml").getPath());
        doubleParser = DoubleParser.getInstance();
        integerParser = IntegerParser.getInstance();
    }

    public void testMaxLat() throws Exception {
        double maxLat = Double.parseDouble(validationConfig.getProperty("param.lat.restriction.max"));
        try {
            doubleParser.parseParam("" + (maxLat + 1), "lat");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.max", "lat", ""+maxLat, "" + (maxLat + 1)));
        }

        double check = doubleParser.parseParam("" + maxLat, "lat");
        assertEquals(check, maxLat);
    }

    public void testMinLat() throws Exception {
        double minLat = Double.parseDouble(validationConfig.getProperty("param.lat.restriction.min"));
        try {
            doubleParser.parseParam("" + (minLat - 1), "lat");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.min", "lat", ""+minLat, "" + (minLat -  1)));
        }
        double check = doubleParser.parseParam("" + minLat, "lat");
        assertEquals(check, minLat);
    }
    
    public void testMaxLon() throws Exception {
        double maxLon = Double.parseDouble(validationConfig.getProperty("param.lon.restriction.max"));
        try {
            doubleParser.parseParam("" + (maxLon + 1), "lon");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.max", "lon", ""+maxLon, "" + (maxLon + 1)));
        }

        double check = doubleParser.parseParam("" + maxLon, "lon");
        assertEquals(check, maxLon);
    }

    public void testMinLon() throws Exception {
        double minLon = Double.parseDouble(validationConfig.getProperty("param.lon.restriction.min"));
        try {
            doubleParser.parseParam("" + (minLon - 1), "lon");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.min", "lon", ""+minLon, "" + (minLon -  1)));
        }
        double check = doubleParser.parseParam("" + minLon, "lon");
        assertEquals(check, minLon);
    }


    public void testMinLimit() throws Exception {
        int minLimit = Integer.parseInt(validationConfig.getProperty("param.limit.restriction.min"));
        try {
            integerParser.parseParam("" + (minLimit - 1), "limit");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.min", "limit", ""+minLimit, "" + (minLimit -  1)));
        }
        int check = integerParser.parseParam("" + minLimit, "limit");
        assertEquals(check, minLimit);
    }

    public void testMaxLimit() throws Exception {
        int maxLimit = Integer.parseInt(validationConfig.getProperty("param.limit.restriction.max"));
        try {
            integerParser.parseParam("" + (maxLimit - 1), "limit");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.max", "limit", ""+maxLimit, "" + (maxLimit -  1)));
        }
        int check = integerParser.parseParam("" + maxLimit, "limit");
        assertEquals(check, maxLimit);
    }

    public void testMinOffset() throws Exception {
        int minOffset = Integer.parseInt(validationConfig.getProperty("param.offset.restriction.min"));
        try {
            integerParser.parseParam("" + (minOffset - 1), "offset");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.min", "offset", ""+minOffset, "" + (minOffset -  1)));
        }
        int check = integerParser.parseParam("" + minOffset, "offset");
        assertEquals(check, minOffset);
    }

    public void testMaxOffset() throws Exception {
        int maxOffset = Integer.parseInt(validationConfig.getProperty("param.offset.restriction.max"));
        try {
            integerParser.parseParam("" + (maxOffset - 1), "offset");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.max", "offset", ""+maxOffset, "" + (maxOffset -  1)));
        }
        int check = integerParser.parseParam("" + maxOffset, "offset");
        assertEquals(check, maxOffset);
    }
    
    public void testMinWidth() throws Exception {
        int minWidth = Integer.parseInt(validationConfig.getProperty("param.width.restriction.min"));
        try {
            integerParser.parseParam("" + (minWidth - 1), "width");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.min", "width", ""+minWidth, "" + (minWidth -  1)));
        }
        int check = integerParser.parseParam("" + minWidth, "width");
        assertEquals(check, minWidth);
    }

    public void testMaxWidth() throws Exception {
        int maxWidth = Integer.parseInt(validationConfig.getProperty("param.width.restriction.max"));
        try {
            integerParser.parseParam("" + (maxWidth - 1), "width");
        } catch(ParamValidationException e) {
            assertEquals(e.getMessage(), expectMessage("message.max", "width", ""+maxWidth, "" + (maxWidth -  1)));
        }
        int check = integerParser.parseParam("" + maxWidth, "width");
        assertEquals(check, maxWidth);
    }

    public void testNonExistentValidation() throws Exception {
        try {
            double test = doubleParser.parseParam("30.12", "foo");
            assertEquals(test, 30.12);
            int test1 = integerParser.parseParam("12", "bar");
            assertEquals(test1, 12);
        } catch(Exception e) {
            fail("Parser attempted to validate value for parameter with no validation attached to it");
        }
    }

    public void testThrowsNullExceptionOnEmptyRequiredParam() throws Exception {
        try {
            doubleParser.parseParam(null, "foo");
            fail("Parser failed to throw null pointer exception on required unset parameter");
        } catch(NullPointerException e) {
            assertEquals(e.getMessage(), "Required parameter foo not supplied");
        }

        try {
            integerParser.parseParam(null, "foo");
            fail("Parser failed to throw null pointer exception on required unset parameter");
        } catch(NullPointerException e) {
            assertEquals(e.getMessage(), "Required parameter foo not supplied");
        }
    }

    public void testThrowsNumberFormatException() throws Exception {
        try {
            doubleParser.parseParam("s2eda", "foo");
            fail("Parser failed to throw number format exception on invalid number");
        } catch(NumberFormatException e) {
            assertEquals(e.getMessage(), "Parameter foo has invalid format");
        }

        try {
            integerParser.parseParam("s2eda", "foo");
            fail("Parser failed to throw number format exception on invalid number");
        } catch(NumberFormatException e) {
            assertEquals(e.getMessage(), "Parameter foo has invalid format");
        }
    }

    public void testAutoCastToDefaultValue() throws Exception {
        double test = doubleParser.parseParam(null, "foo", "123.4");
        assertEquals(test, 123.4);
        int test1 = integerParser.parseParam(null, "foo", "123");
        assertEquals(test1, 123);
    }


    private static String expectMessage(String propertyName, String paramName, String restrictionValue, String paramValue) {
        return validationConfig.getProperty(propertyName)
                .replace("##PARAM_NAME##", paramName)
                .replace("##RESTRICTION_VALUE##", restrictionValue)
                .replace("##PARAM_VALUE##", paramValue);

    }
}
