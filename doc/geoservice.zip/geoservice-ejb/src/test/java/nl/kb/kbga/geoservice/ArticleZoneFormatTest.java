package nl.kb.kbga.geoservice;

import junit.framework.TestCase;
import nl.kb.kbga.geoservice.model.ArticleZone;
import nl.kb.kbga.geoservice.transform.ArticleZoneUrlWrapper;
import nl.kb.kbga.geoservice.transform.ImageViewerConfig;

public class ArticleZoneFormatTest extends TestCase {
    private static ArticleZone articleZone = new ArticleZone();
    private static ImageViewerConfig imageViewerConfig;


    @Override
    public void setUp() throws Exception {
        super.setUp();
        System.setProperty("jboss.server.base.dir", "");
        imageViewerConfig = ImageViewerConfig.getInstance(this.getClass().getResource("/imageviewer.xml").getPath());
        articleZone.setId(1L);
        articleZone.setSortOrder(0);
        articleZone.setArticleUrn("asd:asd:asd");
        articleZone.setImageUrn("asd:asd:asd");
        articleZone.setHpos(0);
        articleZone.setVpos(0);
        articleZone.setWidth(10);
        articleZone.setHeight(10);
        articleZone.setResponseWidth(10);
    }

    public void testUrlGeneration() throws Exception {
        ArticleZoneUrlWrapper wrapper = new ArticleZoneUrlWrapper();
        wrapper.add(articleZone, new String[] {}, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));
        assertEquals(imageViewerConfig.getProperty("baseUrl") + "?id=asd%3Aasd%3Aasd%3Aimage&x=0&y=0&w=10&h=10&s=1.0&q=" + imageViewerConfig.getProperty("paramValue.q"), wrapper.getList().get(0));
    }

    public void testUrlGenerationWithWords() throws Exception {
        ArticleZoneUrlWrapper wrapper = new ArticleZoneUrlWrapper();
        wrapper.add(articleZone, new String[] {
                "first word",
                "second word"
        }, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));
        assertEquals(imageViewerConfig.getProperty("baseUrl") + "?id=asd%3Aasd%3Aasd%3Aimage&x=0&y=0&w=10&h=10&s=1.0&q=" + imageViewerConfig.getProperty("paramValue.q"), wrapper.getList().get(0));
    }

    public void testLinkGeneration() throws Exception {
        ArticleZoneUrlWrapper wrapper = new ArticleZoneUrlWrapper();
        ArticleZone aZone1 = new ArticleZone();
        aZone1.setHpos(0);
        aZone1.setVpos(0);
        aZone1.setWidth(10);
        aZone1.setHeight(10);
        aZone1.setResponseWidth(10);
        aZone1.setArticleUrn("ddd:010664188:mpeg21:a0094");
        aZone1.setImageUrn("ddd:010664188:mpeg21:p002:image");
        wrapper.add(aZone1, new String[] {}, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));
        System.out.println("HERE: " + wrapper.getLink());
    }
}
