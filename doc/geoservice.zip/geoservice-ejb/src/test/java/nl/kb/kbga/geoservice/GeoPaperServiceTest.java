package nl.kb.kbga.geoservice;

import nl.kb.kbga.geoservice.model.Article;
import nl.kb.kbga.geoservice.model.ArticleZone;
import nl.kb.kbga.geoservice.service.GeoPaperServiceImpl;
import nl.kb.kbga.geoservice.transform.GeoServiceResultSet;
import nl.kb.kbga.geoservice.transform.ImageViewerConfig;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.ArrayList;
import java.util.List;

/**
 * Test cases for GeoPaperService
 */
public class GeoPaperServiceTest extends junit.framework.TestCase {
    static {
        BasicConfigurator.configure();
        Logger.getInstance("org.hibernate").setLevel(Level.INFO);
        Logger.getInstance("org.apache").setLevel(Level.INFO);
    }
    private static Logger logger = Logger.getRootLogger();
    private static List<Article> loadedArticleList = new ArrayList<Article>();
    private static ImageViewerConfig imageViewerConfig;

    private EntityManager entityManager;
    private EntityManagerFactory factory;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        System.setProperty("jboss.server.base.dir", "");
        imageViewerConfig = ImageViewerConfig.getInstance(this.getClass().getResource("/imageviewer.xml").getPath());
        factory = Persistence.createEntityManagerFactory("inMemory");
        entityManager = factory.createEntityManager();
        logger.info("Building mock article data");
        entityManager.getTransaction().begin();
        for(long i = 0; i < 10; ++i) {
            Article a = new Article();
            a.setId(i);
            a.setArticleUrn("test:urn:" + i);
            a.setLatitude(51 + (0.001 * i));
            a.setLongitude(4 + (0.001 * i));
            a.setTitle("test title " + i);
            a.setPaperTitle("test paper title " + i);
            a.setPlace("place " + i);
            a.setStreet("street " + i);
            a.setSortOrder(0);
            loadedArticleList.add(a);
            entityManager.persist(a);

            for(int j = 0; j < 3; j++) {
                ArticleZone az = new ArticleZone();
                az.setId(new Long(i + "" + j));
                az.setArticleUrn("test:urn:" + i);
                az.setHeight(100);
                az.setWidth(100);
                az.setHpos(j * 100);
                az.setVpos(100);
                az.setImageUrn("test:urn:image:" + i + ":" + j);
                az.setSortOrder(j);
                entityManager.persist(az);
            }

        }
        entityManager.getTransaction().commit();
        logger.info("Created mock article data");
    }

    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
        if (entityManager != null) { entityManager.close(); }
        if (factory != null) { factory.close(); }
    }

    @Test
    public void testProximitySearch1() throws Exception {
        GeoPaperServiceImpl service = new GeoPaperServiceImpl();
        service.setEntityManager(entityManager);
        entityManager.getTransaction().begin();
        logger.info("Performing first search");
        GeoServiceResultSet aList1 = service.proximitySearch(51.0, 4.0, 0, 20, 300, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));
        logger.info("Performing second search, closest to third entry of loaded data");
        GeoServiceResultSet aList2 = service.proximitySearch(51.003, 4.003, 0, 20, 300, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));
        entityManager.getTransaction().commit();
        GeoServiceResultSet broadList = service.proximitySearch(51.45, 4.45, 0, 20, 300, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));

        logger.info("Asserting first search returned results");
        assertNotNull(aList1);
        logger.info("Asserting second search returned results");
        assertNotNull(aList2);
        assertNotNull(broadList);

        logger.info("Asserting first search returned a list in the original sortation");
        assertEquals(loadedArticleList, aList1.getArticles());
        logger.info("Asserting first hit of second search equals third entry of loaded list");
        assertEquals(loadedArticleList.get(3), aList2.getArticles().get(0));
        assertEquals(10, broadList.getArticles().size());
    }

    @Test
    public void testProximityCount1() throws Exception {
        GeoPaperServiceImpl service = new GeoPaperServiceImpl();
        service.setEntityManager(entityManager);
        entityManager.getTransaction().begin();
        long resultCount = service.getResultCount(51.0, 4.0, false);
        long emptyCount = service.getResultCount(52.0, 5.0, false);
        long resultCountBroad = service.getResultCount(51.45, 4.45, true);
        entityManager.getTransaction().commit();
        assertEquals(10, resultCount);
        assertEquals(0, emptyCount);
        assertEquals(10, resultCountBroad);
    }

    @Test
    public void testGetArticleZones() throws Exception {
        GeoPaperServiceImpl service = new GeoPaperServiceImpl();
        service.setEntityManager(entityManager);
        logger.info("RETRIEVING ARTICLE ZONES");
        GeoServiceResultSet result = service.getArticleZones("test:urn:0", 100, Integer.parseInt(imageViewerConfig.getProperty("paramValue.q")));
        logger.info("Asserting that the generated URLs meet expectations");
        assertEquals(imageViewerConfig.getProperty("baseUrl") + "?id=test%3Aurn%3Aimage%3A0%3A0%3Aimage&x=0&y=100&w=100&h=100&s=1.0&q=" + imageViewerConfig.getProperty("paramValue.q"),
                result.getImageUrls().getList().get(0));
        assertEquals(imageViewerConfig.getProperty("baseUrl") + "?id=test%3Aurn%3Aimage%3A0%3A1%3Aimage&x=100&y=100&w=100&h=100&s=1.0&q=" + imageViewerConfig.getProperty("paramValue.q"),
                result.getImageUrls().getList().get(1));
    }


}
