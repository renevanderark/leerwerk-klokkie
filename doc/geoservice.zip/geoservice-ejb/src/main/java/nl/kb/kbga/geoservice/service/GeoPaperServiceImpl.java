/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.service;

import nl.kb.kbga.geoservice.model.Article;
import nl.kb.kbga.geoservice.model.ArticleZone;
import nl.kb.kbga.geoservice.transform.GeoServiceResultSet;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * {@inheritDoc}
 * @See nl.kb.kbga.geoservice.service.GeoPaperSevice
 */
@Stateless
public class GeoPaperServiceImpl implements GeoPaperService {

    private static final long serialVersionUID = 1L;
    private static final String LAT_PARAMETER_NAME = "lat";
    private static final String LON_PARAMETER_NAME = "lon";
    private static final String URN_NAMED_PARAM = "articleUrn";

    @PersistenceContext
    private EntityManager entityManager;

    /**
     * {@inheritDoc}
     * @See nl.kb.kbga.geoservice.service.GeoPaperSevice#getResultCount
     */
    public Long getResultCount(double latParam, double lonParam, boolean broad) {
        return (
            (Long)
                (broad ?
                    entityManager.createNamedQuery("BroadCount") :
                    entityManager.createNamedQuery("ProximityCount")
                ).setParameter(LAT_PARAMETER_NAME, latParam)
                .setParameter(LON_PARAMETER_NAME, lonParam)
                .getSingleResult());
    }

    /**
     * {@inheritDoc}
     * @See nl.kb.kbga.geoservice.service.GeoPaperSevice#proximitySearch
     */
    public GeoServiceResultSet proximitySearch(
            double latParam, double lonParam, int offsetParam, int limitParam, int widthParam, int qualityParam) {

        GeoServiceResultSet resultSet = new GeoServiceResultSet();
        boolean broad = false;
        long resultCount = getResultCount(latParam, lonParam, false);
        if(resultCount == 0) {
            broad = true;
            resultCount = getResultCount(latParam, lonParam, true);
        }
        Query query =
                broad ?
                entityManager.createNamedQuery("BroadSearch") :
                entityManager.createNamedQuery("ProximitySearch");

        query.setParameter(LAT_PARAMETER_NAME, latParam);
        query.setParameter(LON_PARAMETER_NAME, lonParam);
        query.setFirstResult(offsetParam);
        query.setMaxResults(limitParam);

        @SuppressWarnings("unchecked")
        ArrayList<Article> articles = (ArrayList<Article>) query.getResultList();

        Collections.sort(articles, new Comparator<Article>() {
            public int compare(Article o1, Article o2) {
                if(o1.getSortOrder() == null || o2.getSortOrder() == null)
                    return 0;
                return o2.getSortOrder().compareTo(o1.getSortOrder());
            }
        });

        resultSet.setResultCount(resultCount);
        resultSet.setArticles(articles);
        if(articles.size() > 0) {
            String articleUrn = articles.get(0).getArticleUrn();
            resultSet.setImages(getImages(articleUrn, widthParam), getArticleWords(articleUrn), qualityParam);
        }
        return resultSet;
    }

    /**
     * @param articleUrn urn of the article
     * @return url formatted words found in the article
     */
    private String[] getArticleWords(String articleUrn) {
        Query query = entityManager.createQuery("FROM Article WHERE articleUrn = :articleUrn");
        query.setParameter(URN_NAMED_PARAM, articleUrn);
        ArrayList<Article> result = (ArrayList<Article>) query.getResultList();
        Article article = (Article) result.get(0);
        return new String[] {article.getStreet(), article.getPlace()};
    }

    /**
     * @param articleUrn unique URN identifier for article
     * @param widthParam the width of the images
     * @return arraylist of article zone objects
     */
    private ArrayList<ArticleZone> getImages(String articleUrn, int widthParam) {
        Query query = entityManager.createNamedQuery("SortedZones");
        query.setParameter(URN_NAMED_PARAM, articleUrn);

        @SuppressWarnings("unchecked")
        ArrayList<ArticleZone> articleZones = (ArrayList<ArticleZone>) query.getResultList();
        for(ArticleZone articleZone : articleZones) {
            articleZone.setResponseWidth(widthParam);
        }
        return articleZones;
    }

    /**
     * {@inheritDoc}
     * @See nl.kb.kbga.geoservice.service.GeoPaperService#getArticleZones
     */
    public GeoServiceResultSet getArticleZones(String articleUrn, int widthParam, int qualityParam)  {

        GeoServiceResultSet restResultSet = new GeoServiceResultSet();
        restResultSet.setImages(getImages(articleUrn, widthParam), getArticleWords(articleUrn), qualityParam);
        return restResultSet;
    }


    /**
	 * Allow test cases to set the entityManager.
	 * @param entityManager the entityManager to use.
	 */
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
}
