/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.model;


import nl.kb.kbga.geoservice.transform.DateFormatterAdapter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.NamedNativeQueries;
import javax.persistence.NamedNativeQuery;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import java.util.Date;


/**
 * Article entity, represents link between article
 * and location, also provides quick access metadata
 * like title and paper title.
 */
@SuppressWarnings({"UnusedDeclaration"})
@Entity
@Table(name="articles")

@SqlResultSetMapping(name="ProximitySearchResults",
    entities={
        @EntityResult(entityClass=nl.kb.kbga.geoservice.model.Article.class, fields={
            @FieldResult(name="id", column="ARTICLE_ID"),
            @FieldResult(name="articleUrn", column="ARTICLE_URN"),
            @FieldResult(name="paperTitle", column="PAPERTITLE"),
            @FieldResult(name="street", column="STREET"),
            @FieldResult(name="place", column="PLACE"),
            @FieldResult(name="title", column="TITLE"),
            @FieldResult(name="latitude", column="LAT"),
            @FieldResult(name="longitude", column="LON"),
            @FieldResult(name="editorialLikes", column="EDITORIAL_LIKES"),
            @FieldResult(name="likes", column="LIKES"),
            @FieldResult(name="sortOrder", column="SORTORDER"),
            @FieldResult(name="date", column="ARTICLE_DATE")
        })}
)


@NamedNativeQueries({
        @NamedNativeQuery(
            name = "ProximitySearch",
            query =
                "SELECT article_id, article_urn, papertitle, title, street, " +
                        "place, lat, lon, likes, editorial_likes, sortorder, article_date, " +
                "( " +
                "   3959 * acos( cos( :lat * 0.017453293 ) * " +
                "   cos( lat * 0.017453293 ) * cos( (lon * 0.017453293)  - " +
                "   (:lon * 0.017453293) ) + sin(:lat * 0.017453293 ) * " +
                "   sin( lat * 0.017453293 ) ) " +
                ")  dst " +
                "FROM articles " +
                "WHERE articles.lat < :lat + 0.01 " +
                "AND articles.lat > :lat - 0.01 " +
                "AND articles.lon < :lon + 0.01 " +
                "AND articles.lon > :lon - 0.01 " +
                "ORDER BY dst",
            resultSetMapping = "ProximitySearchResults"
        ),
        @NamedNativeQuery(
            name = "BroadSearch",
            query =
                "SELECT article_id, article_urn, papertitle, title, street, " +
                        "place, lat, lon, likes, editorial_likes, sortorder, article_date, " +
                "( " +
                "   3959 * acos( cos( :lat * 0.017453293 ) * " +
                "   cos( lat * 0.017453293 ) * cos( (lon * 0.017453293)  - " +
                "   (:lon * 0.017453293) ) + sin(:lat * 0.017453293 ) * " +
                "   sin( lat * 0.017453293 ) ) " +
                ")  dst " +
                "FROM articles " +
                "WHERE articles.lat < :lat + 0.5 " +
                "AND articles.lat > :lat - 0.5 " +
                "AND articles.lon < :lon + 0.5 " +
                "AND articles.lon > :lon - 0.5 " +
                "ORDER BY dst",
            resultSetMapping = "ProximitySearchResults"
        )
})

@NamedQueries({
    @NamedQuery(
        name = "ProximityCount",
        query =
            "SELECT COUNT(*) " +
            "FROM Article as article " +
            "WHERE article.latitude < :lat + 0.01 " +
            "AND   article.latitude > :lat - 0.01 " +
            "AND   article.longitude < :lon + 0.01 " +
            "AND   article.longitude > :lon - 0.01 "
    ),
    @NamedQuery(
    name = "BroadCount",
    query =
            "SELECT COUNT(*) " +
            "FROM Article as article " +
            "WHERE article.latitude < :lat + 0.5 " +
            "AND   article.latitude > :lat - 0.5 " +
            "AND   article.longitude < :lon + 0.5 " +
            "AND   article.longitude > :lon - 0.5 "
    )
})

@XmlRootElement(name = "record")
public class Article {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String paperTitle;
    private String articleUrn;
    private String title;
    private String street;
    private String place;
    private Double latitude;
    private Double longitude;
    private Integer editorialLikes;
    private Integer likes;
    private Integer sortOrder;
    private Date date;

    /**
     * @param id database id.
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @param paperTitle the title of the newspaper
     */
    public void setPaperTitle(String paperTitle) {
        this.paperTitle = paperTitle;
    }

    /**
     * @param articleUrn set the URN identifier of the article
     */
    public void setArticleUrn(String articleUrn) {
        this.articleUrn = articleUrn;
    }

    /**
     * @param title the title of the article
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @param street the name of the location
     */
    public void setStreet(String street) {
        this.street = street;
    }

    /**
     * @param place the place or region name of the location
     */
    public void setPlace(String place) {
        this.place = place;
    }

    /**
     * @param latitude the latitude of the location
     */
    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    /**
     * @param longitude the longitude of the location
     */
    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    /**
     * @param editorialLikes featured article score
     */
    public void setEditorialLikes(Integer editorialLikes) {
        this.editorialLikes = editorialLikes;
    }

    /**
     * @param likes audience like score
     */
    public void setLikes(Integer likes) {
        this.likes = likes;
    }

    /**
     * @param sortOrder sort order of articles
     */
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * @param date publication date of the article
     */
    public void setDate(Date date) {
        this.date = date;
    }

    /**
     * @return database id.
     */
    @Id
    @Column(name="article_id")
    @XmlTransient
    public Long getId() {
        return id;
    }

    /**
     * @return the title of the newspaper the article is from
     */
    @Column(name="papertitle")
    @XmlElement(name = "papertitle")
    public String getPaperTitle() {
        return paperTitle;
    }

    /**
     * @return the unique KB MDO URN identifier of the article
     */
    @Column(name="article_urn")
    @XmlElement(name = "urn")
    public String getArticleUrn() {
        return articleUrn;
    }

    /**
     * @return the title of the article
     */
    @Column(name="title")
    @XmlElement
    public String getTitle() {
        return title;
    }

    /**
     * @return the name of the location
     */
    @Column(name="street")
    @XmlElement
    public String getStreet() {
        return street;
    }

    /**
     * @return the place or region name of the location
     */
    @Column(name="place")
    @XmlElement
    public String getPlace() {
        return place;
    }

    /**
     * @return the latitude of the location
     */
    @Column(name="lat")
    @XmlElement
    public Double getLatitude() {
        return latitude;
    }

    /**
     * @return the longitude of the location
     */
    @Column(name="lon")
    @XmlElement
    public Double getLongitude() {
        return longitude;
    }

    /**
     * @return audience like score
     */
    @Column(name="likes")
    @XmlTransient
    public Integer getLikes() {
        return likes;
    }

    /**
     * @return featured article score
     */
    @Column(name="editorial_likes")
    @XmlTransient
    public Integer getEditorialLikes() {
        return editorialLikes;
    }

    /**
     * @return sort order of articles
     */
    @Column(name="sortorder")
    @XmlElement(name = "featured")
    public Integer getSortOrder() {
        return sortOrder;
    }

    /**
     * @return the publication date of the article
     */
    @Column(name="article_date")
    @XmlElement
    @XmlJavaTypeAdapter(DateFormatterAdapter.class)
    public Date getDate() {
        return date;
    }

}
