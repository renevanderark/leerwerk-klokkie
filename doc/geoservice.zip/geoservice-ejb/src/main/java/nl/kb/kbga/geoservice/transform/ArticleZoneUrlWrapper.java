/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.transform;

import nl.kb.kbga.geoservice.model.ArticleZone;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.URIException;
import org.apache.commons.httpclient.methods.GetMethod;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * JAXB Wrapper class for urls of article-zone images.
 */
@XmlRootElement(name = "images")
public class ArticleZoneUrlWrapper {
    private static final String PAPER_BASE_URL = "http://kranten.kb.nl/view/article/id/";
    private static final ImageViewerConfig IMAGE_VIEWER_CONFIG =
            ImageViewerConfig.getInstance("/customconf/geoservice/imageviewer.xml");
    private List<String> list = new ArrayList<String>();
    private String link = "";

    /**
     * Constructor.
     */
    public ArticleZoneUrlWrapper() { }

    /**
     * @param articleZone to create a url from to add to the list
     * @param words the words for the highlighter
     * @param quality the quality of the images
     */
    public void add(ArticleZone articleZone, String[] words, int quality) {
        list.add(makeUrl(articleZone, words, quality));
    }

    /**
     * @param words the words for the highlighter
     * @return the words for the highlighter as string parameter
     */
    private String catWords(String[] words) {
        StringBuilder wordString = new StringBuilder();
        for(String word : words) {
            wordString.append("\"").append(word).append("\" ");
        }
        return wordString.toString().trim();
    }

    /**
     * @param articleZone the article-zone
     * @param words the words for the highlighter
     * @param quality the quality of the image
     * @return the image viewer url for this article zone
     */
    public String makeUrl(ArticleZone articleZone, String[] words, int quality) {
        if(link.length() == 0) {
            link = PAPER_BASE_URL + articleZone.getImageId().
                    replaceAll(":image$", ":" + articleZone.getArticleUrn().replaceAll(".+:", "") );
        }
        GetMethod method = new GetMethod(IMAGE_VIEWER_CONFIG.getProperty("baseUrl"));

        method.setQueryString(new NameValuePair[] {
                new NameValuePair(IMAGE_VIEWER_CONFIG.getProperty("paramName.id"), articleZone.getImageId()),
                new NameValuePair(IMAGE_VIEWER_CONFIG.getProperty("paramName.x"),
                                Integer.toString(articleZone.getScaledXPosition())),
                new NameValuePair(IMAGE_VIEWER_CONFIG.getProperty("paramName.y"),
                                Integer.toString(articleZone.getScaledYPosition())),
                new NameValuePair(IMAGE_VIEWER_CONFIG.getProperty("paramName.w"),
                        Integer.toString(articleZone.getScaledWidth())),
                new NameValuePair(IMAGE_VIEWER_CONFIG.getProperty("paramName.h"),
                        Integer.toString(articleZone.getScaledHeight())),
                new NameValuePair(IMAGE_VIEWER_CONFIG.getProperty("paramName.s"),
                        Float.toString(articleZone.getScaleFactor())),
                new NameValuePair(IMAGE_VIEWER_CONFIG.getProperty("paramName.q"),
                        Integer.toString(quality))
        });
        try {
            return method.getURI().toString();
        } catch(URIException e) {
            throw new RuntimeException("Unable to build uri from article zone object", e);
        }

    }

    /**
     * @return the list of urls
     */
    @XmlElement(name = "record")
    public List<String> getList() { return list; }

    /**
     * @return link to kranten.kb.nl
     */
    @XmlElement(name = "link")
    public String getLink() { return link; }
}