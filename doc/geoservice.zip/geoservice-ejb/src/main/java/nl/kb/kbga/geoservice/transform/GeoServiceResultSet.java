/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.transform;

import nl.kb.kbga.geoservice.model.Article;
import nl.kb.kbga.geoservice.model.ArticleZone;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.List;

/**
 * JAXB Wrapper for database resultsets.
 */
@SuppressWarnings("unused")
@XmlRootElement(name = "results")
public class GeoServiceResultSet {
    private List<Article> articles = null;
    private Long resultCount = null;
    private ArticleZoneUrlWrapper imageUrls = new ArticleZoneUrlWrapper();

    /**
     * @return the number of search results
     */
    @XmlElement(name = "resultcount")
    public Long getResultCount() {
        return resultCount;
    }

    /**
     * @param resultCount the result count
     */
    public void setResultCount(long resultCount) {
        this.resultCount = resultCount;
    }

    /**
     * @return the list articles in the resultset
     */
    @XmlElementWrapper
    @XmlElement(name = "record")
    public List<Article> getArticles() {
        return articles;
    }

    /**
     * @param articles the list of articles in the result-set
     */
    public void setArticles(ArrayList<Article> articles) {
        this.articles = articles;
    }


    /**
     * @return jaxb wrapper for article-zone objects
     */
    @XmlElement(name = "images")
    public ArticleZoneUrlWrapper getImageUrls() {
        return imageUrls;
    }

    /**
     * @param articleZones the list of article-zones in the result-set
     * @param words the words for the highlighter
     * @param quality the quality of the images
     */
    public void setImages(List<ArticleZone> articleZones, String[] words, int quality) {
        for(ArticleZone articleZone : articleZones) {
            imageUrls.add(articleZone, words, quality);
        }
    }
}
