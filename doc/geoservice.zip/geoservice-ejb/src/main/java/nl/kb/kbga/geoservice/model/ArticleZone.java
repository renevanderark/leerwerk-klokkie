/**
 * Copyright (c) 2012, Koninklijke Bibliotheek - Nationale bibliotheek van Nederland
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation
 *     and/or other materials provided with the distribution.
 *   * Neither the name of the Koninklijke Bibliotheek nor the names of its contributors
 *     may be used to endorse or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
package nl.kb.kbga.geoservice.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * Represents the zone on the image of the article.
 */
@Entity
@Table(name="ARTIKEL_ZONES")
@NamedQuery(
    name = "SortedZones",
    query =
        "FROM ArticleZone as article_zone " +
        "WHERE article_zone.articleUrn = :articleUrn " +
        "ORDER BY article_zone.sortOrder"
)
@SuppressWarnings("unused")
public class ArticleZone {

    private static final long serialVersionUID = 1L;
    private static final String URN_REPLACE_PATTERN = ":a[0-9]{4}$";
    private String articleUrn;
    private Long id;
    private Integer vpos;
    private Integer width;
    private Integer hpos;
    private Integer height;
    private String imageUrn;
    private Integer sortOrder;
    private transient float scaleFactor = 1.0f;

    /**
     * @return database id
     */
    @Id
    @Column(name="ARTIKEL_ZONE_ID")
    public Long getId() {
        return id;
    }

    /**
     * @param id database id
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return urn identifier of article
     */
    @Column(name="ARTIKEL_URN")
    public String getArticleUrn() {
        return articleUrn;
    }

    /**
     * @param articleUrn urn id of article
     */
    public void setArticleUrn(String articleUrn) {
        this.articleUrn = articleUrn;
    }

    /**
     * @return x position of article on image
     */
    @Column(name="HPOS")
    public Integer getHpos() {
        return hpos;
    }

    /**
     * @param hpos xpos of article on image
     */
    public void setHpos(Integer hpos) {
        this.hpos = hpos;
    }

    /**
     * @return height of article on image
     */
    @Column(name="HEIGHT")
    public Integer getHeight() {
        return height;
    }

    /**
     * @param height of article on image
     */
    public void setHeight(Integer height) {
        this.height = height;
    }

    /**
     * @return urn identifier of image
     */
    @Column(name="IMAGE_URN")
    public String getImageUrn() {
        return imageUrn;
    }

    /**
     * @param imageUrn urn identifier of image
     */
    public void setImageUrn(String imageUrn) {
        this.imageUrn = imageUrn;
    }

    /**
     * @return readorder of article zones
     */
    @Column(name="SORTORDER")
    public Integer getSortOrder() {
        return sortOrder;
    }

    /**
     * @param sortOrder readorder of article zones
     */
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    /**
     * @return y position of article on image
     */
    @Column(name="VPOS")
    public Integer getVpos() {
        return vpos;
    }

    /**
     * @param vpos ypos of article on image
     */
    public void setVpos(Integer vpos) {
        this.vpos = vpos;
    }

    /**
     * @return width of article on image
     */
    @Column(name="WIDTH")
    public Integer getWidth() {
        return width;
    }

    /**
     * @param width of article on image
     */
    public void setWidth(Integer width) {
        this.width = width;
    }

    /**
     * @param responseWidth calculates the scale scaleFactor for each image.
     */
    public void setResponseWidth(int responseWidth) {
        this.scaleFactor = (float) responseWidth / (float) this.width;
    }

    /**
     * @return hpos scaled to x position at return width
     */
    @Transient
    public int getScaledXPosition() {
        return (int) (((float) hpos) * scaleFactor);
    }

    /**
     * @return vpos scaled to x position at return width
     */
    @Transient
    public int getScaledYPosition() {
        return (int) (((float) vpos) * scaleFactor);
    }

    /**
     * @return hpos scaled to x position at return width
     */
    @Transient
    public int getScaledWidth() {
        return (int) (((float) width) * scaleFactor);
    }

    /**
     * @return vpos scaled to x position at return width
     */
    @Transient
    public int getScaledHeight() {
        return  (int) (((float) height) * scaleFactor);
    }

    /**
     * @return the urn identifier of the word coordinate source file for this article
     */
    @Transient
    public String getCoords() {
        return imageUrn.replaceAll(URN_REPLACE_PATTERN, "") + ":alto";
    }

    /**
     * @return the urn identifier of the image of the page for this article
     */
    @Transient
    public String getImageId() {
        return imageUrn.replaceAll(URN_REPLACE_PATTERN, "") + ":image";
    }

    /**
     * @return the scale factor for the article-zone's image
     */
    @Transient
    public float getScaleFactor() {
        return scaleFactor;
    }
}
